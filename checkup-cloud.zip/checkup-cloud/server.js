// ========================================================================
// SPRINT 5 - "CHECK-UP CLOUD"
// Backend completo: Autenticação (JWT), Memória (MongoDB), Multimodal
// (Cloudinary), Function Calling (clima) e Health Check real.
// ========================================================================

require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const fetch = require("node-fetch");
const { GoogleGenerativeAI, SchemaType } = require("@google/generative-ai");

const app = express();
const PORT = process.env.PORT || 3000;

// ------------------------------------------------------------------------
// Middlewares básicos
// ------------------------------------------------------------------------
app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());

// ------------------------------------------------------------------------
// Conexão com o MongoDB
// ------------------------------------------------------------------------
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("[MongoDB] Conectado com sucesso."))
  .catch((err) => console.error("[MongoDB] Erro ao conectar:", err.message));

// ------------------------------------------------------------------------
// Configuração do Cloudinary
// ------------------------------------------------------------------------
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});
const upload = multer({ storage: multer.memoryStorage() });

// ------------------------------------------------------------------------
// Modelos (Schemas) do MongoDB
// ------------------------------------------------------------------------
const userSchema = new mongoose.Schema({
  nome: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  senha: { type: String, required: true },
  criadoEm: { type: Date, default: Date.now },
});
const User = mongoose.model("User", userSchema);

const messageSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  role: { type: String, enum: ["user", "model"], required: true },
  text: { type: String, required: true },
  imageUrl: { type: String, default: null },
  criadoEm: { type: Date, default: Date.now },
});
const Message = mongoose.model("Message", messageSchema);

// ------------------------------------------------------------------------
// Middleware de autenticação (protege as rotas privadas com JWT)
// ------------------------------------------------------------------------
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ erro: "Token não fornecido." });
  }
  const token = authHeader.split(" ")[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = payload.id;
    next();
  } catch (err) {
    return res.status(401).json({ erro: "Token inválido ou expirado." });
  }
}

// ========================================================================
// ROTA DE HEALTH CHECK (pública, NÃO protegida por JWT)
// Verifica de verdade a conexão com o MongoDB, não apenas se o Express
// está de pé. readyState 1 = conectado.
// ========================================================================
app.get("/api/health", async (req, res) => {
  const mongoState = mongoose.connection.readyState; // 0,1,2,3
  const bancoConectado = mongoState === 1;

  const payload = {
    status: bancoConectado ? "ok" : "degradado",
    bancoDeDados: bancoConectado ? "conectado" : "desconectado",
    timestamp: new Date().toISOString(),
  };

  // Se o banco não está conectado, o sistema NÃO está saudável de verdade.
  // Retornamos 503 (Service Unavailable) em vez de mascarar com 200.
  if (!bancoConectado) {
    return res.status(503).json(payload);
  }

  return res.status(200).json(payload);
});

// ========================================================================
// AUTENTICAÇÃO
// ========================================================================
app.post("/api/register", async (req, res) => {
  try {
    const { nome, email, senha } = req.body;
    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: "Preencha nome, email e senha." });
    }

    const existente = await User.findOne({ email });
    if (existente) {
      return res.status(409).json({ erro: "Este e-mail já está cadastrado." });
    }

    const senhaHash = await bcrypt.hash(senha, 10);
    const novoUsuario = await User.create({ nome, email, senha: senhaHash });

    const token = jwt.sign({ id: novoUsuario._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    return res.status(201).json({
      token,
      usuario: { id: novoUsuario._id, nome: novoUsuario.nome, email: novoUsuario.email },
    });
  } catch (err) {
    console.error("[Register] Erro:", err.message);
    return res.status(500).json({ erro: "Erro interno ao cadastrar usuário." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, senha } = req.body;
    const usuario = await User.findOne({ email });
    if (!usuario) {
      return res.status(401).json({ erro: "E-mail ou senha inválidos." });
    }

    const senhaValida = await bcrypt.compare(senha, usuario.senha);
    if (!senhaValida) {
      return res.status(401).json({ erro: "E-mail ou senha inválidos." });
    }

    const token = jwt.sign({ id: usuario._id }, process.env.JWT_SECRET, {
      expiresIn: "7d",
    });

    return res.json({
      token,
      usuario: { id: usuario._id, nome: usuario.nome, email: usuario.email },
    });
  } catch (err) {
    console.error("[Login] Erro:", err.message);
    return res.status(500).json({ erro: "Erro interno ao fazer login." });
  }
});

// ========================================================================
// HISTÓRICO / MEMÓRIA (protegido por JWT)
// ========================================================================
app.get("/api/history", authMiddleware, async (req, res) => {
  try {
    const historico = await Message.find({ userId: req.userId }).sort({ criadoEm: 1 });
    return res.json(historico);
  } catch (err) {
    return res.status(500).json({ erro: "Erro ao buscar histórico." });
  }
});

app.delete("/api/history", authMiddleware, async (req, res) => {
  try {
    await Message.deleteMany({ userId: req.userId });
    return res.json({ mensagem: "Histórico apagado com sucesso." });
  } catch (err) {
    return res.status(500).json({ erro: "Erro ao apagar histórico." });
  }
});

// ========================================================================
// UPLOAD DE IMAGEM (Cloudinary) - protegido por JWT
// ========================================================================
app.post("/api/upload", authMiddleware, upload.single("imagem"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ erro: "Nenhuma imagem enviada." });
    }

    const resultado = await new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream(
        { folder: "checkup-cloud" },
        (error, result) => (error ? reject(error) : resolve(result))
      );
      stream.end(req.file.buffer);
    });

    return res.json({ url: resultado.secure_url });
  } catch (err) {
    console.error("[Upload] Erro:", err.message);
    return res.status(500).json({ erro: "Erro ao enviar imagem para o Cloudinary." });
  }
});

// ========================================================================
// FUNCTION CALLING - Ferramenta de clima (Open-Meteo, sem necessidade de API key)
// ========================================================================
async function getWeather(cidade) {
  try {
    const geoResp = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cidade)}&count=1&language=pt`
    );
    const geoData = await geoResp.json();

    if (!geoData.results || geoData.results.length === 0) {
      return { erro: `Não encontrei a cidade "${cidade}".` };
    }

    const { latitude, longitude, name } = geoData.results[0];
    const climaResp = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`
    );
    const climaData = await climaResp.json();

    return {
      cidade: name,
      temperatura: `${climaData.current_weather.temperature}°C`,
      vento: `${climaData.current_weather.windspeed} km/h`,
    };
  } catch (err) {
    return { erro: "Não consegui consultar a previsão do tempo agora." };
  }
}

const weatherFunctionDeclaration = {
  name: "getWeather",
  description: "Retorna a temperatura atual e o vento de uma cidade informada.",
  parameters: {
    type: SchemaType.OBJECT,
    properties: {
      cidade: {
        type: SchemaType.STRING,
        description: "Nome da cidade, ex: 'Tóquio' ou 'São Paulo'.",
      },
    },
    required: ["cidade"],
  },
};

// ========================================================================
// CHAT (protegido por JWT) - integra Gemini, memória e function calling
// ========================================================================
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

app.post("/api/chat", authMiddleware, async (req, res) => {
  try {
    const { mensagem, imageUrl } = req.body;
    if (!mensagem) {
      return res.status(400).json({ erro: "Mensagem vazia." });
    }

    // Salva a mensagem do usuário no banco (memória)
    await Message.create({
      userId: req.userId,
      role: "user",
      text: mensagem,
      imageUrl: imageUrl || null,
    });

    // Recupera as últimas 20 mensagens para dar contexto ao modelo
    const historico = await Message.find({ userId: req.userId })
      .sort({ criadoEm: -1 })
      .limit(20);
    historico.reverse();

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
      tools: [{ functionDeclarations: [weatherFunctionDeclaration] }],
    });

    // Monta o histórico no formato esperado pela API do Gemini
    const contents = historico.map((m) => {
      const parts = [{ text: m.text }];
      return { role: m.role, parts };
    });

    // Se a última mensagem tiver imagem, anexa como parte inline
    if (imageUrl) {
      const imgResp = await fetch(imageUrl);
      const imgBuffer = await imgResp.buffer();
      contents[contents.length - 1].parts.push({
        inlineData: {
          mimeType: "image/jpeg",
          data: imgBuffer.toString("base64"),
        },
      });
    }

    let result = await model.generateContent({ contents });
    let response = result.response;

    // Verifica se o modelo pediu para chamar a função de clima
    const funcCall = response.functionCalls && response.functionCalls()[0];
    let textoFinal;

    if (funcCall && funcCall.name === "getWeather") {
      const dadosClima = await getWeather(funcCall.args.cidade);

      const segundaChamada = await model.generateContent({
        contents: [
          ...contents,
          { role: "model", parts: [{ functionCall: funcCall }] },
          {
            role: "function",
            parts: [{ functionResponse: { name: "getWeather", response: dadosClima } }],
          },
        ],
      });
      textoFinal = segundaChamada.response.text();
    } else {
      textoFinal = response.text();
    }

    // Salva a resposta da IA no banco (memória)
    await Message.create({ userId: req.userId, role: "model", text: textoFinal });

    return res.json({ resposta: textoFinal });
  } catch (err) {
    console.error("[Chat] Erro:", err.message);
    return res.status(500).json({ erro: "Erro ao processar a mensagem." });
  }
});

// ------------------------------------------------------------------------
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
