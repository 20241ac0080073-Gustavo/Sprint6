# Agente IA — Check-up Cloud (Sprint 5)

Chatbot com IA generativa, memória persistente, suporte a imagens e clima em tempo real, com auditoria de qualidade, health check real e monitoramento de disponibilidade.

**Backend em produção:** `https://SEU-BACKEND.onrender.com`
**Front-end em produção:** `https://SEU-FRONTEND.vercel.app`

## Tecnologias utilizadas

- **Backend:** Node.js, Express
- **Banco de dados:** MongoDB (Mongoose)
- **Autenticação:** JWT + bcrypt
- **IA Generativa:** Google Gemini (`@google/generative-ai`), com Function Calling
- **Upload de imagens:** Cloudinary
- **Clima (function calling):** Open-Meteo (API gratuita, sem chave)
- **Front-end:** HTML, CSS e JavaScript puro
- **Monitoramento:** UptimeRobot consultando `/api/health`

## Funcionalidades

- Cadastro e login com JWT
- Chat com IA que mantém memória das conversas (MongoDB)
- Botão para limpar histórico (apaga do banco de verdade)
- Envio de imagens (Cloudinary) com interpretação pela IA
- Function Calling: a IA consulta a temperatura atual de qualquer cidade
- Rota `GET /api/health` que verifica de verdade a conexão com o MongoDB
- Indicador visual 🟢/🔴 no front-end, integrado ao `/api/health`

## Como rodar localmente

```bash
# instalar dependências
npm install

# copiar o arquivo de exemplo e preencher com suas chaves reais
cp .env.example .env

# subir o servidor
npm start
```

O front-end (pasta `public/`) pode ser aberto com qualquer servidor estático (ex: extensão Live Server do VS Code). Lembre de configurar a constante `API_URL` em `public/index.js` apontando para o backend correto.

## Variáveis de ambiente necessárias

Veja `.env.example`. Nenhuma chave real deve ser commitada no repositório.

## Health Check

A rota `GET /api/health` retorna:

```json
{
  "status": "ok",
  "bancoDeDados": "conectado",
  "timestamp": "2026-09-15T10:30:00.000Z"
}
```

Se o MongoDB estiver indisponível, a rota retorna **HTTP 503** com `"bancoDeDados": "desconectado"` — o status HTTP reflete a saúde real do sistema, não apenas se o processo Express está de pé.

## Monitoramento (UptimeRobot)

Um monitor HTTP(s) foi configurado no [UptimeRobot](https://uptimerobot.com) apontando para `/api/health`, com intervalo de 14 minutos, para evitar o "cold start" do plano gratuito do Render e alertar em caso de indisponibilidade.

## Relatório de Auditoria

O relatório de QA desta Sprint (matriz de testes, bugs encontrados/corrigidos e evidências) está disponível em `relatorio-auditoria.docx` (ou no link do Google Docs informado na entrega).
